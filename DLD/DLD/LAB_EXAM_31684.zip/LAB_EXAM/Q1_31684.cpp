// Abdullah Siraj Khan 31684

#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <map>

using namespace std;

class Sample {
private:
    int n;
    vector<double> tree;

public:
    Sample(const vector<double>& p) {
        n = p.size();
        tree.assign(2*n,0.0);

        for (int i = 0; i < n; i++)
            tree[n + i] = p[i];

        for (int i = n - 1; i >= 1; i--)
            tree[i] = tree[2 * i] + tree[2 * i + 1];
    }

    int random() {
        double r = ((double) rand() / RAND_MAX)*tree[1];
        int k=1;

        while(k<n){
            if(r<tree[2*k]){
                k=2*k;
            } else{
                r-=tree[2*k];
                k=2*k+1;
            }
        }
        return k - n;
    }

    void changeWeight(int i, double v) {
        int k=n+i;
        tree[k]=v;

        while(k>1){
            k/=2;
            tree[k]=tree[2*k]+tree[2*k+1];
        }
    }
};



int main(){

    // Test

    // Test 1: Basic sampling
    vector<double> weights = {1.0, 2.0, 3.0, 4.0};
    Sample sampler(weights);
    
    // Sample 10000 times and count frequencies
    map<int, int> counts;
    for (int i = 0; i < 10000; i++) {
        int idx = sampler.random();
        counts[idx]++;
    }
    
    cout << "Sampling frequencies (out of 10000):" << "\n";
    double total = 10.0;
    for (int i = 0; i < 4; i++) {
        double expected = weights[i] / total * 10000;
        cout << "Index " << i << ": " << counts[i] 
             << " (expected ~" << expected << ")" << "\n";
    }
    
    // Test 2: Weight update
    cout << "\nChanging weight[2] from 3.0 to 8.0" << "\n";
    sampler.changeWeight(2, 8.0); // Update weight in sampler
    weights[2] = 8.0; // Update local copy
    
    counts.clear();
    for (int i = 0; i < 10000; i++) {
        int idx = sampler.random();
        counts[idx]++;
    }
    
    total = 15.0;
    cout << "New sampling frequencies:" << "\n";
    for (int i = 0; i < 4; i++) {
        double expected = weights[i] / total * 10000;
        cout << "Index " << i << ": " << counts[i] 
             << " (expected ~" << expected << ")" << "\n";
    }
    



    return 0;
}
