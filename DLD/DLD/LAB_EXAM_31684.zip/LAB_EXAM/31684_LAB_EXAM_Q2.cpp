// Abdullah Siraj Khan ERP : 31684 

#include <iostream>
#include <vector>
#include <stack>
#include <queue>
using namespace std;

class GRAPH {
    vector<vector<int>> adj;
    int v;
    int e;

public:
    GRAPH(int v) {
        this->v = v;
        e = 0;
        adj.resize(v);
    }

    int V() const {
        return v;
    }

    int E() const {
        return e;
    }

    void addEdge(int u, int v) {
        adj[u].push_back(v);
        e++;
    }

    const vector<int>& neighbour(int u) const {
        return adj[u];
    }

    bool hasedge(int u, int v) {
        for (int i : neighbour(u)) {
            if (i == v)
                return true;
        }
        return false;
    }

    int out_degree(int u) {
        return neighbour(u).size();
    }

    void display() {
        for (int i = 0; i < v; i++) {
            cout << i << " : ";
            for (int j : neighbour(i)) {
                cout << j << " ";
            }
            cout << endl;
        }
    }

    void dfs_utill(int start, vector<bool>& visited, stack<int>& s) {
        visited[start] = true;
        for (int i : neighbour(start)) {
            if (!visited[i]) {
                dfs_utill(i, visited, s);
            }
        }
        s.push(start);
    }

    void topo_sort() {
        vector<bool> visited(v, false);
        stack<int> s;
        for (int i = 0; i < v; i++) {
            if (!visited[i]) {
                dfs_utill(i, visited, s);
            }
        }
        while (!s.empty()) {
            cout << s.top() << " ";
            s.pop();
        }
        cout << endl;
    }
};

// My question 2 answer 

int shortestCycle(const GRAPH& G) {
    int V = G.V();
    const int inf =1e9;
    int ans=inf;

    for (int start=0; start<V; start++) {
        vector<int> dist(V,-1);
        queue<int> q;

        dist[start]=0;
        q.push(start);

        while(!q.empty()) {
            int u=q.front();
            q.pop();

            for (int v : G.neighbour(u)) {
                if(v==start) {
                    ans = min(ans, dist[u] + 1);
                }
                if (dist[v] == -1) {
                    dist[v] = dist[u] + 1;
                    q.push(v);
                }
            }
        }
    }

    return (ans==inf) ? -1 : ans;
}


int main() {
    GRAPH g(5);

    g.addEdge(0, 1);
    g.addEdge(1, 2);
    g.addEdge(2, 0); 
    g.addEdge(2, 3);
    g.addEdge(3, 4);
    g.addEdge(4, 2); 

    cout<<" Shortest cycle length : "<<shortestCycle(g)<<endl;    // It should detect shortest cycle of length 3

     g.addEdge(1,0);

     cout<<" Shortest cycle length : "<<shortestCycle(g)<<endl; // now it should be 2


     // test cases given in the LAB 

 
      // Test 1: Simple cycle of length 4
    int V1 = 4;
    GRAPH G1(V1);
    G1.addEdge(0, 1);
    G1.addEdge(1, 2);
    G1.addEdge(2, 3);
    G1.addEdge(3, 0);
    cout << "Test 1: " << shortestCycle(G1) << "\n";  // 4
    
    // Test 2: Multiple cycles, shortest is 2
    int V2 = 5;
   GRAPH G2(V2);
    G2.addEdge(0, 1);
    G2.addEdge(1, 2);
    G2.addEdge(1, 3);
    G2.addEdge(2, 4);
    G2.addEdge(3, 4);
    G2.addEdge(4, 3);
    cout << "Test 2: " << shortestCycle(G2) << "\n";  // 2
    
    // Test 3: No cycle (DAG)
    int V3 = 3;
   GRAPH G3(V3);
    G3.addEdge(0, 1);
    G3.addEdge(1, 2);
    cout << "Test 3: " << shortestCycle(G3) << "\n";  // -1

    
    // Test 4: Self-loop
    int V4 = 1;
    GRAPH G4(V4);
    G4.addEdge(0, 0);
    cout << "Test 4: " << shortestCycle(G4) << "\n";  // 1
    
    // Test 5: Triangle (shortest cycle is 3)
    int V5 = 3;
    GRAPH G5(V5);
    G5.addEdge(0, 1);
    G5.addEdge(1, 2);
    G5.addEdge(2, 0);
    cout << "Test 5: " << shortestCycle(G5) << "\n";  // 3



    return 0;
}
